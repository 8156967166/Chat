//
//  BaseViewController.swift
//  Chat
//
//  Created by Bimal@AppStation on 14/11/22.
//

import UIKit

class BaseChatAppViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

}
